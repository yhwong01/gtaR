library(httr)        # For making API requests to Yelp
library(jsonlite)    # For parsing JSON responses
library(dplyr)       # For data wrangling
library(ggplot2)
library(gtaR)

df <- search_restaurants (term = "Dim Sum", location = "Vancouver, BC", min_price = "$$", max_price = "$$$$",limit = 10)
df
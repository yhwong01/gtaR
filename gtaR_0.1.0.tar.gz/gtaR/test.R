library(httr)        # For making API requests to Yelp
library(jsonlite)    # For parsing JSON responses
library(dplyr)       # For data wrangling
library(ggplot2)
library(gtaR)



search_restaurants(location = "Vancouver, BC", term = "sushi", limit = 5)

search_restaurants(location = "Burnaby, BC", term = "pizza", min_price = 2, max_price = 4, limit = 10)

search_restaurants(location = "Richmond, BC", term = "dim sum", sort_by = "rating", limit = 8)


search_restaurants(location = "Surrey, BC", term = "Mexican", price_sort = "asc", limit = 5)
